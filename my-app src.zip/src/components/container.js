import './container.css';
function App() {
  return (
    <div className="blank">
      <div>
        <h1 >Let's Get Started</h1>
        <div>
          <input type="checkbox" name="" id="" />Yes
        </div>

        <div>
          <input type="checkbox" name="" id="" />No
        </div>
      </div>
    </div>
  );
}

export default App;
